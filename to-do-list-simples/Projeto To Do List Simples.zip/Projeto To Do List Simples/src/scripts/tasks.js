import { postData, getData, deleteData } from "./api.js";

let tasks = document.getElementById("tasks");
let input = document.getElementById("input");
let ul = document.getElementById("tasklist");
const createbtn = document.getElementById("btn");

createbtn.addEventListener("click", async (e) => {
  e.preventDefault();
  createbtn.disabled = true; // disables the button to avoid multiple requests of the user
  const inputValue = input.value;

  if(inputValue === "") {
    alert("o campo não pode ser vazio");
    createbtn.disabled = false;
  } else {
    createbtn.disabled = true; // disables the button to avoid multiple requests of the user
    setTimeout(await postData(inputValue), 5000);
    createbtn.disabled = false;
  }
})

// renders all tasks created to the list
async function renderTasks() {
  const tasks = await getData();
  ul.innerHTML = "";
  ul.innerHTML += tasks.map((task) => {
    return `
      <li id=${task.id} class="task">
        <input type="checkbox">
        <p>${task.title}</p>
        <button class="btnDelete">Delete</button>
      </li>
    `
  }).join("");

  const btnDelete = document.querySelectorAll(".btnDelete");
  btnDelete.forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      const id = e.target.parentElement.id;
      deleteData(id);
    })
  })
}
renderTasks()
