const url = "http://localhost:3000/tasks";

async function fetchData() {
  const response = await fetch(url);
  const json = await response.json();
  return json;
}

export async function getData() {
  const data = await fetchData();
  return data;
}

async function fetchPostData(id, title) {
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "content-type": "application/json"
    },
    body: JSON.stringify({id, title})
  })
}

export async function postData(value) {
  const data = await getData();

  if(data.length === 0) {
    await fetchPostData("1", value);
  } else {
    let id = await Number(data[data.length - 1].id) + 1;
    await fetchPostData(id + "", value);
  }
}

export async function deleteData(id) {
  await fetch(url + `/${id}`, {method: "DELETE"});
}


